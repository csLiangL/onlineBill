self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "10e2b80993e6bd988e7a",
    "url": "css/app.655d3ae5.css"
  },
  {
    "revision": "e6a90ae9fddf66b95712",
    "url": "css/chunk-4761811e.c7da8d8c.css"
  },
  {
    "revision": "6f580e6c67b2d09db480",
    "url": "css/chunk-a058a44e.5ef79abf.css"
  },
  {
    "revision": "38d337a6210b10d0987a",
    "url": "css/chunk-vendors.40116108.css"
  },
  {
    "revision": "479f207f8ef966d58694b4c447ad4c8c",
    "url": "img/account.479f207f.svg"
  },
  {
    "revision": "b49685d069e7446ec0190ec35ed13770",
    "url": "img/budget.b49685d0.svg"
  },
  {
    "revision": "2fe491800c9477889609a3a517650688",
    "url": "img/cate.2fe49180.svg"
  },
  {
    "revision": "9ab5a7cec24e7b3746efdc91b1a2e3b0",
    "url": "img/charts-active.9ab5a7ce.svg"
  },
  {
    "revision": "18a1ff108202678954e7f3480912c267",
    "url": "img/charts.18a1ff10.svg"
  },
  {
    "revision": "02475fbb45be3ea84cd833a78c18c63e",
    "url": "img/edit.02475fbb.svg"
  },
  {
    "revision": "9733acb3166a0e660bba80d17afa2242",
    "url": "img/home-active.9733acb3.svg"
  },
  {
    "revision": "c55c1b35b05664adf54eed8c58fa497b",
    "url": "img/home.c55c1b35.svg"
  },
  {
    "revision": "dade1c2cec4d4eac5de90e4815265552",
    "url": "img/note.dade1c2c.svg"
  },
  {
    "revision": "ce47a9d436566355d451b7a9686e62e6",
    "url": "img/profile-active.ce47a9d4.svg"
  },
  {
    "revision": "f1decc174c9660ccbc4e3d9a60eb6482",
    "url": "img/profile.f1decc17.svg"
  },
  {
    "revision": "271a6130c734a8f2e4f5b7d4f393a8fa",
    "url": "img/pulldown.271a6130.svg"
  },
  {
    "revision": "856ae0b6348977f6252b2c9c7e7238bd",
    "url": "img/return-active.856ae0b6.svg"
  },
  {
    "revision": "bcd9c2a91d789431b767e444a35df336",
    "url": "img/return.bcd9c2a9.svg"
  },
  {
    "revision": "bd757812ed52a3fefa63d2a5736bf989",
    "url": "img/submit.bd757812.svg"
  },
  {
    "revision": "37a187b05f0c982a8215216965be765b",
    "url": "img/time.37a187b0.svg"
  },
  {
    "revision": "e70bea0ed73d0d8b063c560f8e18ca70",
    "url": "img/user.e70bea0e.svg"
  },
  {
    "revision": "05db8855a8f13e15b9df45336fc38b7b",
    "url": "index.html"
  },
  {
    "revision": "10e2b80993e6bd988e7a",
    "url": "js/app.115131b3.js"
  },
  {
    "revision": "e6a90ae9fddf66b95712",
    "url": "js/chunk-4761811e.7b9fbf78.js"
  },
  {
    "revision": "6f580e6c67b2d09db480",
    "url": "js/chunk-a058a44e.202d9d17.js"
  },
  {
    "revision": "38d337a6210b10d0987a",
    "url": "js/chunk-vendors.060ee88f.js"
  },
  {
    "revision": "1f134956c66d295d990604debf55d6fe",
    "url": "manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "revision": "f07f9309cad856eb24f1e28cc4dc97d8",
    "url": "static/lib/echarts.min.js"
  }
]);